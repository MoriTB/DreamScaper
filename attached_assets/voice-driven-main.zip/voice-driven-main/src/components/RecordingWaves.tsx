
import React from 'react';

const RecordingWaves: React.FC = () => {
  return (
    <div className="flex items-end justify-center space-x-1 h-16 w-full">
      {[...Array(20)].map((_, i) => (
        <div
          key={i}
          className="w-1 bg-dream rounded-full animate-wave"
          style={{
            height: `${Math.random() * 60 + 20}%`,
            animationDelay: `${i * 0.05}s`
          }}
        />
      ))}
    </div>
  );
};

export default RecordingWaves;
