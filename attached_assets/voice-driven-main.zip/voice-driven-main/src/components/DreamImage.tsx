
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface DreamImageProps {
  imagePrompt: string;
}

const DreamImage: React.FC<DreamImageProps> = ({ imagePrompt }) => {
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Simulate image generation delay
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // For demonstration, we're using a placeholder image
  // In a real app, this would be generated based on the imagePrompt
  const placeholderImage = "https://source.unsplash.com/photo-1470071459604-3b5ec3a7fe05";
  
  return (
    <Card className="border border-dream/30 shadow-lg overflow-hidden bg-gradient-to-br from-dream-light/20 to-dream-blue/30 backdrop-blur-sm">
      <CardContent className="p-4">
        <h2 className="text-2xl font-semibold mb-4 text-center">Dream Visualization</h2>
        
        <div className="relative aspect-video rounded-lg overflow-hidden">
          {isLoading ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-dream-dark/10">
              <div className="h-10 w-10 rounded-full border-4 border-dream border-t-transparent animate-spin mb-4"></div>
              <p className="text-dream-secondary">Creating your dream image...</p>
            </div>
          ) : (
            <img 
              src={placeholderImage} 
              alt="Dream visualization" 
              className="w-full h-full object-cover transition-all duration-1000 animate-fade-in"
            />
          )}
        </div>
        
        <p className="mt-4 text-sm text-muted-foreground italic text-center">
          {isLoading ? "Generating visualization based on your dream description..." : "Image generated based on your dream description"}
        </p>
      </CardContent>
    </Card>
  );
};

export default DreamImage;
