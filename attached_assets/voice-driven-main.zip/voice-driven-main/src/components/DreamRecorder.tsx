
import React, { useState } from 'react';
import { Mic } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import RecordingWaves from './RecordingWaves';
import { useToast } from "@/hooks/use-toast";

const DreamRecorder: React.FC<{
  onDreamRecorded: (dream: string) => void;
}> = ({ onDreamRecorded }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const { toast } = useToast();
  
  const startRecording = () => {
    // In a real app, we would use the Web Speech API or a similar service
    setIsRecording(true);
    
    // For demonstration, we'll use a timer to simulate recording
    const timer = setInterval(() => {
      setRecordingTime(prev => prev + 1);
    }, 1000);
    
    // Simulate ending the recording after some time
    setTimeout(() => {
      clearInterval(timer);
      stopRecording();
    }, 10000); // Simulate 10 seconds of recording
  };
  
  const stopRecording = () => {
    setIsRecording(false);
    
    // In a real app, we would process the audio recording
    // For demonstration, we'll use a sample dream text
    const sampleDreamText = "I was flying over a purple ocean. The sky was filled with stars even though it was daytime. Below me, I could see strange creatures swimming in the water. They looked like a mix between dolphins and dragons. I flew down to touch the water and it felt warm and electric. Then I saw a small island with a glowing tree in the center.";
    
    toast({
      title: "Dream Recorded",
      description: "Your dream has been successfully captured!",
    });
    
    onDreamRecorded(sampleDreamText);
    setRecordingTime(0);
  };
  
  return (
    <Card className="border border-dream/30 shadow-lg bg-gradient-to-br from-dream-light/20 to-dream-blue/30 backdrop-blur-sm">
      <CardContent className="p-6 flex flex-col items-center">
        <h2 className="text-2xl font-semibold mb-6 text-center text-foreground">Record Your Dream</h2>
        
        {isRecording ? (
          <div className="flex flex-col items-center w-full">
            <RecordingWaves />
            <div className="mt-4 text-xl font-medium">{recordingTime}s</div>
            <Button 
              variant="destructive" 
              size="lg" 
              className="mt-6 rounded-full px-8 py-6 text-lg"
              onClick={stopRecording}
            >
              Stop Recording
            </Button>
          </div>
        ) : (
          <Button 
            variant="default" 
            size="lg" 
            className="bg-dream hover:bg-dream-secondary transition-all duration-300 rounded-full h-20 w-20 flex items-center justify-center shadow-lg"
            onClick={startRecording}
          >
            <Mic className="h-10 w-10" />
          </Button>
        )}
        
        <p className="mt-6 text-center text-muted-foreground">
          {isRecording 
            ? "Speak clearly about your dream..." 
            : "Tap the microphone and start describing your dream"
          }
        </p>
      </CardContent>
    </Card>
  );
};

export default DreamRecorder;
