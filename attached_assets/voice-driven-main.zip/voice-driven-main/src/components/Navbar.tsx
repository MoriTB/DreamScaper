
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Moon, LogIn, UserPlus, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuLink,
  navigationMenuTriggerStyle,
} from '@/components/ui/navigation-menu';

const Navbar = () => {
  const navigate = useNavigate();
  const isLoggedIn = false; // Replace with actual auth state when implemented

  return (
    <header className="w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="flex items-center space-x-2 mr-4" onClick={() => navigate('/')} style={{ cursor: 'pointer' }}>
          <Moon className="h-6 w-6 text-dream" />
          <span className="font-bold text-lg hidden md:inline-block">DreamJournal</span>
        </div>
        
        <NavigationMenu className="hidden md:flex">
          <NavigationMenuList>
            <NavigationMenuItem>
              <NavigationMenuLink 
                className={navigationMenuTriggerStyle()}
                onClick={() => navigate('/')}
                style={{ cursor: 'pointer' }}
              >
                Home
              </NavigationMenuLink>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <NavigationMenuLink 
                className={navigationMenuTriggerStyle()}
                onClick={() => navigate('/journal')}
                style={{ cursor: 'pointer' }}
              >
                Journal
              </NavigationMenuLink>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <NavigationMenuLink 
                className={navigationMenuTriggerStyle()}
                onClick={() => navigate('/subscription')}
                style={{ cursor: 'pointer' }}
              >
                Subscription
              </NavigationMenuLink>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>
        
        <div className="ml-auto flex items-center space-x-2">
          {isLoggedIn ? (
            <Button variant="ghost" size="icon" onClick={() => navigate('/profile')}>
              <User className="h-5 w-5" />
            </Button>
          ) : (
            <>
              <Button variant="ghost" onClick={() => navigate('/login')}>
                <LogIn className="h-5 w-5 mr-2" />
                <span className="hidden sm:inline-block">Sign In</span>
              </Button>
              <Button variant="default" onClick={() => navigate('/signup')}>
                <UserPlus className="h-5 w-5 mr-2" />
                <span className="hidden sm:inline-block">Sign Up</span>
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
