
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

interface DreamAnalysisProps {
  dreamText: string;
  onSaveDream: (analysis: DreamAnalysisResult) => void;
}

export interface DreamAnalysisResult {
  dreamText: string;
  interpretation: string;
  symbols: string[];
  mood: string;
  imagePrompt: string;
}

const DreamAnalysis: React.FC<DreamAnalysisProps> = ({ dreamText, onSaveDream }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [analysisStep, setAnalysisStep] = useState<'transcribing' | 'analyzing' | 'generating' | 'complete'>('transcribing');
  const [analysis, setAnalysis] = useState<DreamAnalysisResult | null>(null);

  // Simulate the analysis process
  useEffect(() => {
    // Step 1: Transcribing
    setTimeout(() => {
      setAnalysisStep('analyzing');
      
      // Step 2: Analyzing
      setTimeout(() => {
        setAnalysisStep('generating');
        
        // Step 3: Generating image prompt
        setTimeout(() => {
          setAnalysisStep('complete');
          setIsAnalyzing(false);
          
          // Generate mock analysis
          const mockAnalysis: DreamAnalysisResult = {
            dreamText,
            interpretation: "Your dream about flying over a purple ocean suggests a sense of freedom and exploration. The strange creatures may represent unknown aspects of yourself or untapped creativity. The warm, electric water symbolizes emotional energy, while the glowing tree on the island could represent wisdom or a goal you're reaching for.",
            symbols: ["Flying", "Ocean", "Creatures", "Island", "Glowing Tree"],
            mood: "Mystical, Adventurous",
            imagePrompt: "A surreal scene with a person flying over a purple ocean with dolphin-dragon hybrids swimming below, and a small island with a luminescent tree in the center, under a star-filled daytime sky"
          };
          
          setAnalysis(mockAnalysis);
        }, 2000);
      }, 2000);
    }, 2000);
  }, [dreamText]);

  const handleSave = () => {
    if (analysis) {
      onSaveDream(analysis);
    }
  };

  return (
    <Card className="border border-dream/30 shadow-lg bg-gradient-to-br from-dream-light/20 to-dream-blue/30 backdrop-blur-sm">
      <CardContent className="p-6">
        <h2 className="text-2xl font-semibold mb-4 text-center">Dream Analysis</h2>
        
        {isAnalyzing ? (
          <div className="flex flex-col items-center justify-center space-y-4 py-8">
            <div className="h-8 w-8 rounded-full border-4 border-dream border-t-transparent animate-spin"></div>
            <p className="text-lg font-medium">
              {analysisStep === 'transcribing' && "Transcribing your dream..."}
              {analysisStep === 'analyzing' && "Analyzing dream symbols..."}
              {analysisStep === 'generating' && "Creating dream visualization..."}
            </p>
          </div>
        ) : analysis ? (
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium text-dream-secondary">Your Dream</h3>
              <p className="mt-1 text-foreground">{analysis.dreamText}</p>
            </div>
            
            <Separator className="my-4" />
            
            <div>
              <h3 className="text-lg font-medium text-dream-secondary">Interpretation</h3>
              <p className="mt-1 text-foreground">{analysis.interpretation}</p>
            </div>
            
            <div className="flex flex-wrap gap-2 mt-4">
              {analysis.symbols.map((symbol, index) => (
                <span key={index} className="px-3 py-1 bg-dream/20 text-dream-dark rounded-full text-sm">
                  {symbol}
                </span>
              ))}
            </div>
            
            <div className="mt-4">
              <h3 className="text-lg font-medium text-dream-secondary">Dream Mood</h3>
              <p className="mt-1 text-foreground">{analysis.mood}</p>
            </div>
            
            <div className="mt-6 flex justify-center">
              <Button 
                variant="default" 
                size="lg" 
                className="bg-dream hover:bg-dream-secondary transition-all duration-300"
                onClick={handleSave}
              >
                Save Dream
              </Button>
            </div>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
};

export default DreamAnalysis;
