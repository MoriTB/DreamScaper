
import React from 'react';
import { useNavigate } from 'react-router-dom';

const Footer = () => {
  const navigate = useNavigate();
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="w-full border-t border-border py-8 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-foreground">DreamJournal</h3>
            <p className="text-sm text-muted-foreground">
              Capture and understand your dreams with the power of AI
            </p>
            <p className="text-sm text-muted-foreground">
              © {currentYear} DreamJournal. All rights reserved.
            </p>
          </div>
          
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Quick Links</h3>
            <div className="flex flex-col space-y-2">
              {[
                ['Privacy Policy', '/privacy'],
                ['Terms of Service', '/terms'],
                ['Contact Us', '/contact'],
              ].map(([label, path]) => (
                <a
                  key={path}
                  href="#"
                  onClick={(e) => { e.preventDefault(); navigate(path); }}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200 w-fit"
                >
                  {label}
                </a>
              ))}
            </div>
          </div>
          
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Features</h3>
            <div className="flex flex-col space-y-2">
              {[
                ['Dream Journal', '/journal'],
                ['Dream Analysis', '/'],
                ['Subscription Plans', '/subscription'],
              ].map(([label, path]) => (
                <a
                  key={path}
                  href="#"
                  onClick={(e) => { e.preventDefault(); navigate(path); }}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200 w-fit"
                >
                  {label}
                </a>
              ))}
            </div>
          </div>
          
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Account</h3>
            <div className="flex flex-col space-y-2">
              {[
                ['Profile', '/profile'],
                ['Settings', '/settings'],
                ['Support', '/contact'],
              ].map(([label, path]) => (
                <a
                  key={path}
                  href="#"
                  onClick={(e) => { e.preventDefault(); navigate(path); }}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200 w-fit"
                >
                  {label}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
