
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckIcon } from 'lucide-react';

const Subscription = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-foreground mb-4">Subscription Plans</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Choose the perfect plan to enhance your dream journaling experience and unlock powerful insights.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {/* Free Plan */}
        <Card className="border-2 hover:border-dream transition-all">
          <CardHeader className="text-center">
            <CardTitle>Free</CardTitle>
            <div className="mt-4">
              <span className="text-4xl font-bold">$0</span>
              <span className="text-muted-foreground">/month</span>
            </div>
            <CardDescription className="mt-2">Perfect for casual dream recorders</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ul className="space-y-2">
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Basic dream recording</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Up to 10 dream entries</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Basic dream analysis</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Standard dream symbols</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Start for Free
            </Button>
          </CardFooter>
        </Card>
        
        {/* Premium Plan */}
        <Card className="border-2 border-dream shadow-lg scale-105 relative">
          <div className="absolute top-0 left-0 right-0 bg-dream text-white text-center py-1 text-sm font-medium">
            MOST POPULAR
          </div>
          <CardHeader className="text-center pt-8">
            <CardTitle>Premium</CardTitle>
            <div className="mt-4">
              <span className="text-4xl font-bold">$9.99</span>
              <span className="text-muted-foreground">/month</span>
            </div>
            <CardDescription className="mt-2">For dedicated dream explorers</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ul className="space-y-2">
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Unlimited dream entries</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Advanced dream analysis</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Dream pattern recognition</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Audio dream recording</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Dream visualization tools</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button className="w-full">
              Subscribe Now
            </Button>
          </CardFooter>
        </Card>
        
        {/* Enterprise Plan */}
        <Card className="border-2 hover:border-dream transition-all">
          <CardHeader className="text-center">
            <CardTitle>Enterprise</CardTitle>
            <div className="mt-4">
              <span className="text-4xl font-bold">$19.99</span>
              <span className="text-muted-foreground">/month</span>
            </div>
            <CardDescription className="mt-2">For professional dream analysts</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ul className="space-y-2">
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Everything in Premium</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Advanced dream AI analysis</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Personalized insights</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Priority support</span>
              </li>
              <li className="flex items-start">
                <CheckIcon className="mr-2 h-5 w-5 text-dream flex-shrink-0" />
                <span>Dream-based therapy tools</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Contact Sales
            </Button>
          </CardFooter>
        </Card>
      </div>
      
      <div className="mt-12 text-center max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
        <div className="space-y-4 text-left">
          <div>
            <h3 className="font-semibold">Can I upgrade or downgrade my plan?</h3>
            <p className="text-muted-foreground">Yes, you can change your subscription plan at any time. Changes will be applied at the start of your next billing cycle.</p>
          </div>
          <div>
            <h3 className="font-semibold">Is there a refund policy?</h3>
            <p className="text-muted-foreground">We offer a 7-day money-back guarantee for all new subscriptions.</p>
          </div>
          <div>
            <h3 className="font-semibold">What payment methods do you accept?</h3>
            <p className="text-muted-foreground">We accept all major credit cards and PayPal.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Subscription;
