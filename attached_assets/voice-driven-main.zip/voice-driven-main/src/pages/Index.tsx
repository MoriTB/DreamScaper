
import React, { useState } from 'react';
import DreamRecorder from '@/components/DreamRecorder';
import DreamAnalysis, { DreamAnalysisResult } from '@/components/DreamAnalysis';
import DreamImage from '@/components/DreamImage';
import { saveDream, initializeSampleDreams } from '@/utils/dreamStorage';
import { useNavigate } from 'react-router-dom';
import { useToast } from "@/hooks/use-toast";

const Index = () => {
  const [dreamText, setDreamText] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<DreamAnalysisResult | null>(null);
  const [savedDreamId, setSavedDreamId] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Initialize sample dreams if none exist
  React.useEffect(() => {
    initializeSampleDreams();
  }, []);
  
  const handleDreamRecorded = (text: string) => {
    setDreamText(text);
  };
  
  const handleSaveDream = (analysis: DreamAnalysisResult) => {
    const storedDream = saveDream(analysis);
    setSavedDreamId(storedDream.id);
    setAnalysisResult(analysis);
    
    toast({
      title: "Dream Saved",
      description: "Your dream has been saved to your journal.",
    });
    
    // Automatically navigate to the journal after a short delay
    setTimeout(() => {
      navigate('/journal');
    }, 2000);
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">Dream Journal</h1>
          <p className="text-muted-foreground text-lg">
            Capture, understand, and visualize your dreams with the power of AI
          </p>
        </div>
        
        <div className="space-y-8">
          {!dreamText ? (
            <DreamRecorder onDreamRecorded={handleDreamRecorded} />
          ) : (
            <>
              <DreamAnalysis dreamText={dreamText} onSaveDream={handleSaveDream} />
              {analysisResult && (
                <DreamImage imagePrompt={analysisResult.imagePrompt} />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Index;
