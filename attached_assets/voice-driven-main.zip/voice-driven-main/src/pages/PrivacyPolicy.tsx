
import React from 'react';

const PrivacyPolicy = () => {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
      
      <div className="prose prose-sm max-w-none">
        <p className="text-muted-foreground mb-4">Last updated: April 21, 2025</p>
        
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Introduction</h2>
          <p>
            DreamJournal ("we," "our," or "us") is committed to protecting your privacy. 
            This Privacy Policy explains how your personal information is collected, used, 
            and disclosed by DreamJournal. This Privacy Policy applies to our website and 
            our mobile applications (collectively, our "Service").
          </p>
        </section>
        
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Information We Collect</h2>
          <p className="mb-2">
            We collect information that you provide directly to us when you:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Create or modify your account</li>
            <li>Record dreams and journal entries</li>
            <li>Contact customer support</li>
            <li>Respond to surveys, questionnaires, or requests for feedback</li>
          </ul>
          <p>
            The types of information we may collect include your name, email address, 
            password, dream content, and any other information you choose to provide.
          </p>
        </section>
        
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">How We Use Your Information</h2>
          <p className="mb-2">We use the information we collect to:</p>
          <ul className="list-disc pl-6">
            <li>Provide, maintain, and improve our Service</li>
            <li>Process and complete transactions</li>
            <li>Send you technical notices, updates, security alerts, and support messages</li>
            <li>Respond to your comments, questions, and requests</li>
            <li>Develop new products and services</li>
            <li>Monitor and analyze trends, usage, and activities in connection with our Service</li>
          </ul>
        </section>
        
        {/* More policy sections would go here */}
        
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us at:
            <br />
            <a href="mailto:privacy@dreamjournal.example.com" className="text-dream">
              privacy@dreamjournal.example.com
            </a>
          </p>
        </section>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
