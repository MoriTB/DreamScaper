
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { StoredDream, getDreams } from '@/utils/dreamStorage';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';

const Journal = () => {
  const [dreams, setDreams] = useState<StoredDream[]>([]);
  const navigate = useNavigate();
  
  useEffect(() => {
    const storedDreams = getDreams();
    setDreams(storedDreams);
  }, []);
  
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMMM d, yyyy');
    } catch (e) {
      return dateString;
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-foreground mb-4">Dream Journal</h1>
        <p className="text-muted-foreground text-lg">
          Explore your dream history and uncover patterns
        </p>
      </div>
      
      {dreams.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground text-lg">
            You haven't recorded any dreams yet. Go to the home page to record your first dream!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {dreams.map((dream) => (
            <Card 
              key={dream.id} 
              className="dream-card hover:shadow-lg transition-all duration-300 cursor-pointer"
              onClick={() => navigate(`/dream/${dream.id}`)}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-dream-secondary truncate">{dream.title}</CardTitle>
                <CardDescription className="text-muted-foreground">
                  {formatDate(dream.date)}
                </CardDescription>
              </CardHeader>
              <CardContent className="pb-2">
                <p className="line-clamp-3 text-sm text-foreground">{dream.dreamText}</p>
              </CardContent>
              <CardFooter>
                <div className="flex flex-wrap gap-2">
                  {dream.symbols.slice(0, 3).map((symbol, index) => (
                    <span key={index} className="px-2 py-1 bg-dream/10 text-dream-dark rounded-full text-xs">
                      {symbol}
                    </span>
                  ))}
                  {dream.symbols.length > 3 && (
                    <span className="px-2 py-1 bg-dream/10 text-dream-dark rounded-full text-xs">
                      +{dream.symbols.length - 3}
                    </span>
                  )}
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Journal;
