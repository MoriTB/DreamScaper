
import React from 'react';

const Terms = () => {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>
      
      <div className="prose prose-sm max-w-none">
        <p className="text-muted-foreground mb-4">Last updated: April 21, 2025</p>
        
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Agreement to Terms</h2>
          <p>
            These Terms of Service ("Terms") constitute a legally binding agreement made between you and 
            DreamJournal ("we," "us," or "our") concerning your access to and use of our website and 
            mobile applications (collectively, the "Service"). You agree that by accessing the Service, 
            you have read, understood, and agree to be bound by all of these Terms.
          </p>
        </section>
        
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Use of the Service</h2>
          <p className="mb-2">
            Subject to these Terms, we grant you a limited, non-exclusive, non-transferable, and revocable license to:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Access and use the Service for your personal use</li>
            <li>Record and store dream entries and journal content</li>
            <li>Use the features and functionality made available to you as part of the Service</li>
          </ul>
          <p>
            You agree not to use the Service for any illegal purpose or in violation of any local, state, 
            national, or international law.
          </p>
        </section>
        
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">User Accounts</h2>
          <p className="mb-4">
            To use certain features of the Service, you must register for an account. You agree to provide 
            accurate, current, and complete information during the registration process and to update such 
            information to keep it accurate, current, and complete.
          </p>
          <p>
            You are responsible for safeguarding your password and for all activities that occur under your account. 
            You agree to notify us immediately of any unauthorized use of your account.
          </p>
        </section>
        
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Subscription Terms</h2>
          <p className="mb-4">
            Some aspects of the Service may be provided on a subscription basis. By selecting a subscription plan, 
            you agree to pay the subscription fees indicated for the plan. Subscription fees are non-refundable 
            except as required by law or as explicitly stated in these Terms.
          </p>
          <p>
            We reserve the right to change subscription fees upon reasonable notice. Such notice may be provided 
            through the Service, by email, or by posting the information on our website.
          </p>
        </section>
        
        {/* More terms sections would go here */}
        
        <section className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
          <p>
            If you have any questions about these Terms, please contact us at:
            <br />
            <a href="mailto:terms@dreamjournal.example.com" className="text-dream">
              terms@dreamjournal.example.com
            </a>
          </p>
        </section>
      </div>
    </div>
  );
};

export default Terms;
