
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, Mail, Calendar, Settings } from 'lucide-react';

const Profile = () => {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-6">
        <Card className="w-full md:w-1/3">
          <CardHeader className="text-center">
            <Avatar className="w-24 h-24 mx-auto">
              <AvatarImage src="/placeholder.svg" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <CardTitle className="mt-4">John Doe</CardTitle>
            <CardDescription>Premium Member</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center">
              <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="text-sm">johndoe@example.com</span>
            </div>
            <div className="flex items-center">
              <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Member since April 2025</span>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              <Settings className="mr-2 h-4 w-4" />
              Edit Profile
            </Button>
          </CardFooter>
        </Card>
        
        <div className="w-full md:w-2/3 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Dream Statistics</CardTitle>
              <CardDescription>Your dream journaling activity</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-muted p-4 rounded-lg text-center">
                  <p className="text-3xl font-bold text-dream">23</p>
                  <p className="text-sm text-muted-foreground">Dreams Recorded</p>
                </div>
                <div className="bg-muted p-4 rounded-lg text-center">
                  <p className="text-3xl font-bold text-dream">12</p>
                  <p className="text-sm text-muted-foreground">Days Active</p>
                </div>
                <div className="bg-muted p-4 rounded-lg text-center">
                  <p className="text-3xl font-bold text-dream">5</p>
                  <p className="text-sm text-muted-foreground">Common Themes</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Account Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-medium">Subscription Plan</p>
                <p className="text-muted-foreground">Premium ($9.99/month)</p>
              </div>
              <div>
                <p className="text-sm font-medium">Next Billing Date</p>
                <p className="text-muted-foreground">May 21, 2025</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="mr-2">Manage Subscription</Button>
              <Button variant="destructive">Sign Out</Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Profile;
