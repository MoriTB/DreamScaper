
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { StoredDream, getDreamById } from '@/utils/dreamStorage';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';
import { ArrowLeft } from 'lucide-react';

const DreamDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [dream, setDream] = useState<StoredDream | null>(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    if (id) {
      const foundDream = getDreamById(id);
      if (foundDream) {
        setDream(foundDream);
      }
    }
  }, [id]);
  
  if (!dream) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-semibold">Dream not found</h2>
        <p className="mt-4 text-muted-foreground">The dream you're looking for doesn't exist.</p>
        <Button 
          variant="outline" 
          className="mt-6"
          onClick={() => navigate('/journal')}
        >
          Back to Journal
        </Button>
      </div>
    );
  }
  
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMMM d, yyyy');
    } catch (e) {
      return dateString;
    }
  };
  
  // For demonstration, we're using a placeholder image
  const placeholderImage = "https://source.unsplash.com/photo-1470071459604-3b5ec3a7fe05";
  
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <Button 
        variant="ghost" 
        className="mb-6 pl-2"
        onClick={() => navigate('/journal')}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Journal
      </Button>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <Card className="border border-dream/30 shadow-lg bg-gradient-to-br from-dream-light/20 to-dream-blue/30 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="mb-4">
                <h1 className="text-3xl font-bold text-dream-secondary">{dream.title}</h1>
                <p className="text-muted-foreground">{formatDate(dream.date)}</p>
              </div>
              
              <Separator className="my-4" />
              
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-semibold text-dream-secondary">Dream Description</h2>
                  <p className="mt-2 text-foreground">{dream.dreamText}</p>
                </div>
                
                <div>
                  <h2 className="text-xl font-semibold text-dream-secondary">Interpretation</h2>
                  <p className="mt-2 text-foreground">{dream.interpretation}</p>
                </div>
                
                <div>
                  <h2 className="text-xl font-semibold text-dream-secondary">Symbols</h2>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {dream.symbols.map((symbol, index) => (
                      <span key={index} className="px-3 py-1 bg-dream/20 text-dream-dark rounded-full text-sm">
                        {symbol}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h2 className="text-xl font-semibold text-dream-secondary">Mood</h2>
                  <p className="mt-2 text-foreground">{dream.mood}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card className="border border-dream/30 shadow-lg overflow-hidden bg-gradient-to-br from-dream-light/20 to-dream-blue/30 backdrop-blur-sm">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-dream-secondary mb-4">Dream Visualization</h2>
              <div className="aspect-square rounded-lg overflow-hidden">
                <img 
                  src={placeholderImage} 
                  alt="Dream visualization" 
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="mt-4 text-sm text-muted-foreground italic">
                Image generated based on your dream description
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DreamDetail;
