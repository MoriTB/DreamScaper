
import { DreamAnalysisResult } from "@/components/DreamAnalysis";

export interface StoredDream extends DreamAnalysisResult {
  id: string;
  date: string;
  title: string;
}

export const saveDream = (dream: DreamAnalysisResult): StoredDream => {
  // Generate a unique ID
  const id = Date.now().toString();
  
  // Get current date as ISO string
  const date = new Date().toISOString();
  
  // Generate a title from the first few words
  const words = dream.dreamText.split(' ');
  const title = words.slice(0, 4).join(' ') + (words.length > 4 ? '...' : '');
  
  // Create the stored dream object
  const storedDream: StoredDream = {
    ...dream,
    id,
    date,
    title
  };
  
  // Get existing dreams from localStorage
  const existingDreamsString = localStorage.getItem('dreams');
  const existingDreams: StoredDream[] = existingDreamsString 
    ? JSON.parse(existingDreamsString) 
    : [];
  
  // Add the new dream to the array
  const updatedDreams = [storedDream, ...existingDreams];
  
  // Save back to localStorage
  localStorage.setItem('dreams', JSON.stringify(updatedDreams));
  
  return storedDream;
};

export const getDreams = (): StoredDream[] => {
  const dreamsString = localStorage.getItem('dreams');
  return dreamsString ? JSON.parse(dreamsString) : [];
};

export const getDreamById = (id: string): StoredDream | undefined => {
  const dreams = getDreams();
  return dreams.find(dream => dream.id === id);
};

// If there are no dreams, add some sample dreams
export const initializeSampleDreams = () => {
  const existingDreams = getDreams();
  
  if (existingDreams.length === 0) {
    const sampleDreams: StoredDream[] = [
      {
        id: '1',
        date: new Date(Date.now() - 86400000).toISOString(), // Yesterday
        title: 'Flying over a city...',
        dreamText: 'I was flying over a city with tall glass buildings. The sky was a beautiful shade of orange, like sunset. I could feel the wind against my face and the freedom of soaring through the air.',
        interpretation: 'Flying dreams often represent a sense of freedom, aspiration, and transcending limitations. The orange sunset sky suggests a transition period in your life.',
        symbols: ['Flying', 'City', 'Sunset', 'Freedom'],
        mood: 'Liberating, Peaceful',
        imagePrompt: 'A person flying over a modern city with glass skyscrapers during sunset with an orange sky'
      },
      {
        id: '2',
        date: new Date(Date.now() - 172800000).toISOString(), // Two days ago
        title: 'Lost in a maze...',
        dreamText: 'I was lost in a maze with tall hedges. Every time I thought I found the exit, the path would change. The moon was full and cast strange shadows on the ground.',
        interpretation: 'Being lost in a maze symbolizes feeling confused or trapped in a complex situation in your waking life. The changing paths suggest unpredictability, while the full moon represents illumination or heightened intuition.',
        symbols: ['Maze', 'Moon', 'Shadows', 'Lost'],
        mood: 'Anxious, Confused',
        imagePrompt: 'A person lost in a tall hedge maze at night with a full moon casting shadows on the ground'
      }
    ];
    
    localStorage.setItem('dreams', JSON.stringify(sampleDreams));
  }
};
